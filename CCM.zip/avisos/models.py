from django.contrib.auth.models import AbstractUser
from django.core.validators import RegexValidator
from django.db import models
from django.utils import timezone

id8_validator = RegexValidator(regex=r"^\d{8}$", message="Debe ser un número de 8 dígitos.")

class User(AbstractUser):
    username = None
    id_number = models.CharField("Documento", max_length=10, unique=True,validators=[id8_validator])
    full_name = models.CharField("Nombre completo", max_length=150)
    email = models.EmailField("Email", unique=True)
    USERNAME_FIELD = "id_number"
    REQUIRED_FIELDS = ["full_name", "email"]
    def __str__(self):
        return f"{self.full_name} ({self.id_number})"

class Student(models.Model):
    LEVEL_CHOICES = [("INICIAL", "INICIAL"), ("PRIMARIA", "PRIMARIA"), ("SECUNDARIA", "SECUNDARIA")]
    first_name = models.CharField("Nombre", max_length=100)
    last_name = models.CharField("Apellido", max_length=100)
    level = models.CharField("Nivel", max_length=12, choices=LEVEL_CHOICES)
    grade = models.PositiveSmallIntegerField("Grado/Año")
    active = models.BooleanField(default=True)
    responsibles = models.ManyToManyField("User", through="ResponsibleStudent", related_name="students")
    def __str__(self):
        return f"{self.last_name}, {self.first_name} - {self.level} {self.grade}"

class ResponsibleStudent(models.Model):
    responsible = models.ForeignKey("User", on_delete=models.CASCADE)
    student = models.ForeignKey("Student", on_delete=models.CASCADE)
    class Meta:
        unique_together = ("responsible", "student")

class LateArrival(models.Model):
    responsible = models.ForeignKey("User", on_delete=models.CASCADE)
    student = models.ForeignKey("Student", on_delete=models.CASCADE)
    reason = models.TextField(max_length=500)
    reported_at = models.DateTimeField(default=timezone.now)
