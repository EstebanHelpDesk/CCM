from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as DjangoUserAdmin
from .models import User, Student, ResponsibleStudent, LateArrival

@admin.register(User)
class UserAdmin(DjangoUserAdmin):
    fieldsets = (
        (None, {"fields": ("id_number", "password")}),
        ("Información personal", {"fields": ("full_name", "email")}),
        ("Permisos", {"fields": ("is_active", "is_staff", "is_superuser", "groups", "user_permissions")}),
        ("Fechas", {"fields": ("last_login", "date_joined")}),
    )
    add_fieldsets = (
        (None, {"classes": ("wide",), "fields": ("id_number", "full_name", "email", "password1", "password2")}),
    )
    list_display = ("id_number", "full_name", "email", "is_staff")
    search_fields = ("id_number", "full_name", "email")
    ordering = ("id_number",)

admin.site.register(Student)
admin.site.register(ResponsibleStudent)
admin.site.register(LateArrival)
