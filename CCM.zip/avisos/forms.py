from django import forms
from django.contrib.auth.forms import UserCreationForm
from .models import User, Student

class SignupForm(UserCreationForm):
    class Meta:
        model = User
        fields = ("id_number", "full_name", "email", "password1", "password2")

    def clean(self):
        cleaned_data = super().clean()
        password1 = cleaned_data.get("password1")
        password2 = cleaned_data.get("password2")
        if password1 and password2 and password1 != password2:
            self.add_error("password2", "Las contraseñas no coinciden.")
        return cleaned_data

class UserUpdateForm(forms.ModelForm):
    class Meta:
        model = User
        fields = ("full_name", "email")

class StudentForm(forms.ModelForm):
    class Meta:
        model = Student
        fields = ("first_name", "last_name", "level", "grade", "active")

class NotifyLateForm(forms.Form):
    students = forms.ModelMultipleChoiceField(queryset=Student.objects.none(), widget=forms.CheckboxSelectMultiple)
    reason = forms.CharField(widget=forms.Textarea, max_length=500)
    def __init__(self, *args, **kwargs):
        user = kwargs.pop("user", None)
        super().__init__(*args, **kwargs)
        if user:
            self.fields["students"].queryset = user.students.filter(active=True)
