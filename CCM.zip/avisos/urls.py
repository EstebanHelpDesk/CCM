from django.urls import path
from . import views

urlpatterns = [
    path("perfil/", views.ProfileView.as_view(), name="profile"),
    path("alumnos/registrar/", views.RegisterStudentsView.as_view(), name="register_students"),
    path("avisar-tarde/", views.NotifyLateView.as_view(), name="notify_late"),
    path("avisos/", views.NotificationsListView.as_view(), name="notifications_list"),
]
