from django.contrib import messages
from django.contrib.auth import login
from django.contrib.auth.mixins import LoginRequiredMixin
from django.urls import reverse_lazy
from django.views.generic import TemplateView, CreateView, UpdateView, FormView, ListView
from django.forms import formset_factory
from .forms import SignupForm, UserUpdateForm, StudentForm, NotifyLateForm
from .models import Student, ResponsibleStudent, LateArrival

class HomeView(LoginRequiredMixin, TemplateView):
    template_name = "home.html"

class SignupView(CreateView):
    form_class = SignupForm
    template_name = "auth/signup.html"
    success_url = reverse_lazy("home")
    def form_valid(self, form):
        response = super().form_valid(form)
        login(self.request, self.object)
        return response

class ProfileView(LoginRequiredMixin, UpdateView):
    form_class = UserUpdateForm
    template_name = "avisos/profile.html"
    success_url = reverse_lazy("home")
    def get_object(self):
        return self.request.user

class RegisterStudentsView(LoginRequiredMixin, FormView):
    template_name = "avisos/register_students.html"
    success_url = reverse_lazy("home")
    def get_form_class(self):
        return formset_factory(StudentForm, extra=2, can_delete=True)
    def form_valid(self, formset):
        for form in formset:
            if form.cleaned_data:
                student = form.save()
                ResponsibleStudent.objects.get_or_create(responsible=self.request.user, student=student)
        messages.success(self.request, "Alumnos registrados")
        return super().form_valid(formset)

class NotifyLateView(LoginRequiredMixin, FormView):
    template_name = "avisos/notify_late.html"
    form_class = NotifyLateForm
    success_url = reverse_lazy("notifications_list")
    def get_form_kwargs(self):
        kwargs = super().get_form_kwargs()
        kwargs["user"] = self.request.user
        return kwargs
    def form_valid(self, form):
        for s in form.cleaned_data["students"]:
            LateArrival.objects.create(responsible=self.request.user, student=s, reason=form.cleaned_data["reason"])
        messages.success(self.request, "Aviso enviado")
        return super().form_valid(form)

class NotificationsListView(LoginRequiredMixin, ListView):
    model = LateArrival
    template_name = "avisos/notifications_list.html"
    context_object_name = "notifications"
    def get_queryset(self):
        return LateArrival.objects.filter(responsible=self.request.user)
